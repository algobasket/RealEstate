# PropertyRaja - Real Estate Management System 
![Image of Yaktocat](https://propertyraja.algobasket.com/public/images/realestate.png) 

# Installation
```
ROOT FOLDER > php spark serve
```



