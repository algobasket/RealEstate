<?php

function countries()
{
	$geographyModel = model('GeographyModel');

}