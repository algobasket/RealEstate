# PropertyRaja - Real Estate Management System 
![Image of Yaktocat](https://propertyraja.algobasket.com/public/images/realestate.png) 

# Installation
```
ROOT FOLDER > php spark serve
```
# Auth Credentials
```
----Buyer/Owner---
Mobile - 8800580884
Password - cus123

-------Agent-------
Mobile - 8638720242
Password - agent123

-------Developer/Builder-------
Mobile - 8800580884
Password - dev123

-----Staff/backend (Admin)----
Username - admin123
Password - admin123
AccessToken - 5F0FF80BA9065
```



